(function () {
  "use strict";

  const NEXT_PAGE_FROM_INDEX = "page2.html";
  const QUIZ_PAGE = "quiz.html";
  const PAGE4 = "page4.html";
  const PUZZLE_PAGE = "page3.html";
  const SCRAPBOOK_PAGE = "scrapbook.html";

  const AUDIO_TIME_KEY = "birthdayAudioTime";
  const AUDIO_PAUSED_KEY = "birthdayAudioPaused";

  let effectIntervalsStarted = false;

  document.addEventListener("DOMContentLoaded", function () {
    injectBirthdayStyles();
    ensureEffectContainers();
    setupAudio();
    setupIndexPage();
    setupPuzzlePage();
    setupQuizPage();
    startBackgroundEffects();
  });

  function getCurrentPageName() {
    const path = window.location.pathname;
    const file = path.substring(path.lastIndexOf("/") + 1);
    return file || "index.html";
  }

  function injectBirthdayStyles() {
    if (document.getElementById("birthday-dynamic-style")) {
      return;
    }

    const style = document.createElement("style");
    style.id = "birthday-dynamic-style";

    style.innerHTML = `
      #sideParticles,
      #staticBubbleArea,
      #movingBubbleArea,
      #whiteHeartArea,
      #sparkleArea,
      #crackerArea,
      #butterflyArea {
        position: fixed;
        inset: 0;
        pointer-events: none;
        overflow: hidden;
      }

      #staticBubbleArea {
        z-index: 500;
      }

      #movingBubbleArea {
        z-index: 520;
      }

      #sideParticles {
        z-index: 540;
      }

      #whiteHeartArea {
        z-index: 560;
      }

      #butterflyArea {
        z-index: 2500;
      }

      #crackerArea {
        z-index: 580;
      }

      #sparkleArea {
        z-index: 2600;
      }

      .particle {
        position: absolute;
        will-change: transform, opacity;
        opacity: 0;
        filter: drop-shadow(0 6px 18px rgba(0,0,0,0.25));
      }

      .particle.star {
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: linear-gradient(90deg, #ffd76b, #ffb86b);
      }

      .particle.soft-heart {
        color: rgba(255,255,255,0.92);
        font-size: 24px;
        text-shadow:
          0 0 10px #ffffff,
          0 0 20px rgba(255,255,255,0.75);
      }

      .static-bubble {
        position: absolute;
        border-radius: 50%;
        border: 1px solid rgba(255,255,255,0.35);
        background: rgba(255,255,255,0.09);
        box-shadow: inset 0 0 16px rgba(255,255,255,0.18);
        opacity: 0.75;
      }

      .moving-bubble {
        position: absolute;
        bottom: -90px;
        border-radius: 50%;
        border: 2px solid rgba(255,255,255,0.58);
        background: rgba(255,255,255,0.10);
        box-shadow: inset 0 0 18px rgba(255,255,255,0.18);
        animation: birthdayBubbleMoveUp linear forwards;
      }

      .white-heart {
        position: absolute;
        bottom: -50px;
        color: rgba(255,255,255,0.96);
        font-size: 18px;
        text-shadow:
          0 0 8px #ffffff,
          0 0 18px rgba(255,255,255,0.75),
          0 0 28px rgba(255,215,107,0.45);
        animation:
          birthdayWhiteHeartFloat linear forwards,
          birthdayWhiteHeartBlink 1.4s ease-in-out infinite;
      }

      .butterfly {
        position: absolute;
        bottom: -70px;
        font-size: 34px;
        opacity: 0;
        filter:
          drop-shadow(0 0 10px rgba(255,255,255,0.85))
          drop-shadow(0 0 18px rgba(255,215,107,0.55));
        animation:
          birthdayButterflyFloat linear forwards,
          birthdayButterflyWing 0.8s ease-in-out infinite;
      }

      .sparkle {
        position: absolute;
        width: 7px;
        height: 7px;
        background: #ffffff;
        border-radius: 50%;
        box-shadow:
          0 0 10px #ffffff,
          0 0 22px #ffd76b,
          0 0 36px #ff9fb3;
        animation: birthdaySparkleBlink 1.4s ease-out forwards;
      }

      .cracker {
        position: absolute;
        width: 6px;
        height: 6px;
        background: #ffffff;
        border-radius: 50%;
        animation: birthdayBurst 1.2s ease-out forwards;
      }

      @keyframes birthdayFloatAcross {
        0% {
          transform: translateY(0) translateX(0) scale(0.8);
          opacity: 0;
        }

        10% {
          opacity: 1;
        }

        100% {
          transform: translateY(-40vh) translateX(120vw) scale(1.1);
          opacity: 0;
        }
      }

      @keyframes birthdayFloatAcrossLeft {
        0% {
          transform: translateY(0) translateX(0) scale(0.8);
          opacity: 0;
        }

        10% {
          opacity: 1;
        }

        100% {
          transform: translateY(-40vh) translateX(-120vw) scale(1.1);
          opacity: 0;
        }
      }

      @keyframes birthdayBubbleMoveUp {
        0% {
          transform: translateY(0) scale(0.8);
          opacity: 0;
        }

        15% {
          opacity: 1;
        }

        100% {
          transform: translateY(-115vh) scale(1.2);
          opacity: 0;
        }
      }

      @keyframes birthdayWhiteHeartFloat {
        0% {
          transform: translateY(0) translateX(0) scale(0.8);
          opacity: 0;
        }

        15% {
          opacity: 1;
        }

        100% {
          transform: translateY(-115vh) translateX(35px) scale(1.2);
          opacity: 0;
        }
      }

      @keyframes birthdayWhiteHeartBlink {
        0%, 100% {
          opacity: 0.35;
        }

        50% {
          opacity: 1;
        }
      }

      @keyframes birthdayButterflyFloat {
        0% {
          transform: translateY(0) translateX(0) rotate(0deg) scale(0.8);
          opacity: 0;
        }

        10% {
          opacity: 1;
        }

        30% {
          transform: translateY(-30vh) translateX(45px) rotate(9deg) scale(1);
        }

        60% {
          transform: translateY(-65vh) translateX(-35px) rotate(-9deg) scale(1.12);
        }

        85% {
          opacity: 1;
        }

        100% {
          transform: translateY(-120vh) translateX(55px) rotate(12deg) scale(1.2);
          opacity: 0;
        }
      }

      @keyframes birthdayButterflyWing {
        0%, 100% {
          transform: scale(1) rotate(0deg);
        }

        50% {
          transform: scale(1.22) rotate(5deg);
        }
      }

      @keyframes birthdaySparkleBlink {
        0% {
          transform: scale(0);
          opacity: 0;
        }

        40% {
          transform: scale(1.8);
          opacity: 1;
        }

        100% {
          transform: scale(0);
          opacity: 0;
        }
      }

      @keyframes birthdayBurst {
        0% {
          transform: scale(0.5);
          opacity: 1;
        }

        100% {
          transform: scale(3) translateY(-50px);
          opacity: 0;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function ensureEffectContainers() {
    const containerIds = [
      "sideParticles",
      "staticBubbleArea",
      "movingBubbleArea",
      "whiteHeartArea",
      "sparkleArea",
      "crackerArea",
      "butterflyArea"
    ];

    containerIds.forEach(function (id) {
      if (!document.getElementById(id)) {
        const div = document.createElement("div");
        div.id = id;
        div.setAttribute("aria-hidden", "true");
        document.body.appendChild(div);
      }
    });
  }

  function setupAudio() {
    const audio = document.getElementById("pageAudio");
    const audioToggle = document.getElementById("audioToggle");

    if (!audio) {
      return;
    }

    const savedTime = sessionStorage.getItem(AUDIO_TIME_KEY);
    const savedPaused = sessionStorage.getItem(AUDIO_PAUSED_KEY);

    if (savedTime) {
      try {
        audio.currentTime = parseFloat(savedTime);
      } catch (error) {
        // Ignore invalid saved time.
      }
    }

    if (savedPaused === "false") {
      playBirthdayAudio();
    }

    audio.addEventListener("timeupdate", saveAudioState);
    window.addEventListener("beforeunload", saveAudioState);

    if (audioToggle) {
      audioToggle.addEventListener("click", function () {
        if (audio.paused) {
          playBirthdayAudio();
        } else {
          pauseBirthdayAudio();
        }
      });
    }
  }

  async function playBirthdayAudio() {
    const audio = document.getElementById("pageAudio");
    const audioToggle = document.getElementById("audioToggle");

    if (!audio) {
      return;
    }

    try {
      audio.muted = false;
      audio.volume = 0.8;
      await audio.play();

      sessionStorage.setItem(AUDIO_PAUSED_KEY, "false");

      if (audioToggle) {
        audioToggle.textContent = "Pause Music";
        audioToggle.setAttribute("aria-pressed", "true");
      }
    } catch (error) {
      sessionStorage.setItem(AUDIO_PAUSED_KEY, "true");

      if (audioToggle) {
        audioToggle.textContent = "Play Music";
        audioToggle.setAttribute("aria-pressed", "false");
      }
    }
  }

  function pauseBirthdayAudio() {
    const audio = document.getElementById("pageAudio");
    const audioToggle = document.getElementById("audioToggle");

    if (!audio) {
      return;
    }

    audio.pause();
    sessionStorage.setItem(AUDIO_PAUSED_KEY, "true");

    if (audioToggle) {
      audioToggle.textContent = "Play Music";
      audioToggle.setAttribute("aria-pressed", "false");
    }
  }

  function saveAudioState() {
    const audio = document.getElementById("pageAudio");

    if (!audio) {
      return;
    }

    sessionStorage.setItem(AUDIO_TIME_KEY, audio.currentTime || 0);
    sessionStorage.setItem(AUDIO_PAUSED_KEY, audio.paused ? "true" : "false");
  }

  function setupIndexPage() {
    const pageName = getCurrentPageName();
    const isIndex =
      pageName === "index.html" ||
      pageName === "" ||
      window.location.pathname.endsWith("/");

    if (!isIndex) {
      return;
    }

    const badge = document.getElementById("birthdayBadge");
    const initials = document.getElementById("initials");
    const subtitleChip = document.getElementById("subtitleChip");
    const lead = document.getElementById("lead");
    const line2 = document.getElementById("line2");
    const countdownText = document.getElementById("countdownText");
    const bottomNote = document.getElementById("bottomNote");
    const progressWrap = document.getElementById("progressWrap");
    const progressBar = document.getElementById("progressBar");
    const progressIndicator = document.getElementById("progressIndicator");
    const heartBtn = document.getElementById("heartBtn");

    requestAnimationFrame(function () {
      if (badge) {
        badge.style.opacity = "1";
        badge.style.transform = "translateY(0)";
      }

      if (initials) {
        initials.style.opacity = "1";
        initials.style.transform = "translateY(0)";
      }
    });

    if (subtitleChip) {
      setTimeout(function () {
        subtitleChip.style.opacity = "1";
      }, 250);
    }

    if (lead) {
      setTimeout(function () {
        lead.style.opacity = "1";
      }, 500);
    }

    if (line2) {
      setTimeout(function () {
        line2.style.opacity = "1";
      }, 800);
    }

    setTimeout(function () {
      if (countdownText) {
        countdownText.style.opacity = "1";
      }

      if (bottomNote) {
        bottomNote.style.opacity = "1";
      }
    }, 1100);

    if (progressWrap && progressBar) {
      setTimeout(function () {
        progressWrap.style.opacity = "1";

        setTimeout(function () {
          progressBar.style.width = "100%";

          if (progressIndicator) {
            progressIndicator.style.left = "100%";
          }
        }, 50);
      }, 1200);
    }

    const urlParams = new URLSearchParams(window.location.search);
    const cameFromBack = urlParams.get("fromBack") === "true";

    if (!cameFromBack) {
      setTimeout(function () {
        saveAudioState();
        window.location.href = NEXT_PAGE_FROM_INDEX;
      }, 10000);
    }

    if (heartBtn) {
      heartBtn.addEventListener("click", function () {
        saveAudioState();
        window.location.href = NEXT_PAGE_FROM_INDEX;
      });
    }
  }

  function setupQuizPage() {
    if (!document.getElementById("quizForm")) {
      return;
    }

    window.submitQuiz = function () {
      let score = 0;
      const totalQuestions = 10;

      for (let i = 1; i <= totalQuestions; i++) {
        const selected = document.querySelector('input[name="q' + i + '"]:checked');

        if (selected) {
          score += Number(selected.value);
        }
      }

      const percentage = (score / totalQuestions) * 100;
      const result = document.getElementById("quizResult");

      if (!result) {
        return;
      }

      result.innerHTML = "Your score is " + percentage + "%";

      if (percentage >= 80) {
        result.innerHTML += "<br>Excellent! Next surprise unlocked.";
        result.style.color = "#b8f7e6";
        launchSuccessEffects();

        setTimeout(function () {
          saveAudioState();
          window.location.href = PAGE4;
        }, 1500);
      } else {
        result.innerHTML += "<br>Please try again. You need 80% or above.";
        result.style.color = "#ff9fb3";
      }
    };
  }

  function setupPuzzlePage() {
    const puzzleBoard = document.getElementById("puzzleBoard");

    if (!puzzleBoard) {
      return;
    }

    const correctOrder = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    let currentOrder = [4, 1, 7, 3, 0, 5, 8, 2, 6];
    let selectedIndex = null;

    const puzzleStatus = document.getElementById("puzzleStatus");

    function createPuzzle() {
      puzzleBoard.innerHTML = "";

      currentOrder.forEach(function (pieceNumber, index) {
        const piece = document.createElement("div");

        piece.className = "puzzle-piece";
        piece.dataset.index = index;
        piece.dataset.piece = pieceNumber;

        const row = Math.floor(pieceNumber / 3);
        const col = pieceNumber % 3;

        if (window.innerWidth <= 520) {
          piece.style.backgroundSize = "300px 300px";
          piece.style.backgroundPosition = "-" + col * 100 + "px -" + row * 100 + "px";
        } else {
          piece.style.backgroundSize = "330px 330px";
          piece.style.backgroundPosition = "-" + col * 110 + "px -" + row * 110 + "px";
        }

        piece.addEventListener("click", function () {
          selectPiece(index);
        });

        puzzleBoard.appendChild(piece);
      });
    }

    function selectPiece(index) {
      const pieces = document.querySelectorAll(".puzzle-piece");

      if (selectedIndex === null) {
        selectedIndex = index;
        pieces[index].classList.add("selected");

        if (puzzleStatus) {
          puzzleStatus.innerHTML = "Now select another piece to swap.";
          puzzleStatus.className = "status-box";
        }

        return;
      }

      if (selectedIndex === index) {
        selectedIndex = null;
        createPuzzle();

        if (puzzleStatus) {
          puzzleStatus.innerHTML = "Selection cleared. Choose a piece again.";
          puzzleStatus.className = "status-box";
        }

        return;
      }

      const temp = currentOrder[selectedIndex];
      currentOrder[selectedIndex] = currentOrder[index];
      currentOrder[index] = temp;

      selectedIndex = null;

      createPuzzle();
      checkPuzzle();
    }

    function checkPuzzle() {
      const completed = currentOrder.every(function (value, index) {
        return value === correctOrder[index];
      });

      if (completed) {
        if (puzzleStatus) {
          puzzleStatus.innerHTML = "Perfect! Puzzle completed. Opening scrapbook...";
          puzzleStatus.className = "status-box success-message";
        }

        launchSuccessEffects();

        setTimeout(function () {
          saveAudioState();
          window.location.href = SCRAPBOOK_PAGE;
        }, 1600);
      } else if (puzzleStatus) {
        puzzleStatus.innerHTML = "Good try! Keep arranging the pieces.";
        puzzleStatus.className = "status-box";
      }
    }

    window.shufflePuzzle = function () {
      currentOrder = [4, 1, 7, 3, 0, 5, 8, 2, 6];
      selectedIndex = null;
      createPuzzle();

      if (puzzleStatus) {
        puzzleStatus.innerHTML = "Puzzle shuffled again. Try arranging it correctly.";
        puzzleStatus.className = "status-box";
      }
    };

    window.showHint = function () {
      if (puzzleStatus) {
        puzzleStatus.innerHTML = "Hint: Use the reference image and match each section row by row.";
        puzzleStatus.className = "status-box";
      }
    };

    createPuzzle();

    window.addEventListener("resize", function () {
      createPuzzle();
    });
  }

  window.goBack = function () {
    const pageName = getCurrentPageName();

    saveAudioState();

    if (pageName === "page2.html") {
      window.location.href = "index.html?fromBack=true";
      return;
    }

    if (pageName === "quiz.html") {
      window.location.href = "page2.html";
      return;
    }

    if (pageName === "page4.html") {
      window.location.href = "quiz.html";
      return;
    }

    if (pageName === "page3.html") {
      window.location.href = "page4.html";
      return;
    }

    if (pageName === "scrapbook.html") {
      window.location.href = "page3.html";
      return;
    }

    window.history.back();
  };

  window.goToThirdPage = function () {
    saveAudioState();
    window.location.href = QUIZ_PAGE;
  };

  window.goToPuzzlePage = function () {
    saveAudioState();
    window.location.href = PUZZLE_PAGE;
  };

  window.goToNextPage = function () {
    const pageName = getCurrentPageName();

    saveAudioState();

    if (pageName === "page3.html") {
      window.location.href = SCRAPBOOK_PAGE;
      return;
    }

    if (pageName === "page4.html") {
      window.location.href = PUZZLE_PAGE;
      return;
    }

    window.location.href = QUIZ_PAGE;
  };

  function startBackgroundEffects() {
    if (effectIntervalsStarted) {
      return;
    }

    effectIntervalsStarted = true;

    createStaticBubbles();

    setInterval(createMovingBubble, 500);
    setInterval(createWhiteHeart, 420);
    setInterval(createSideParticle, 740);
    setInterval(createSparkle, 150);
    setInterval(launchCracker, 720);
    setInterval(createButterfly, 650);

    window.addEventListener("resize", function () {
      createStaticBubbles();
    });
  }

  function createStaticBubbles() {
    const area = document.getElementById("staticBubbleArea");

    if (!area) {
      return;
    }

    area.innerHTML = "";

    for (let i = 0; i < 28; i++) {
      const bubble = document.createElement("div");
      const size = 18 + Math.random() * 62;

      bubble.className = "static-bubble";
      bubble.style.width = size + "px";
      bubble.style.height = size + "px";
      bubble.style.left = Math.random() * window.innerWidth + "px";
      bubble.style.top = Math.random() * window.innerHeight + "px";

      area.appendChild(bubble);
    }
  }

  function createMovingBubble() {
    const area = document.getElementById("movingBubbleArea");

    if (!area) {
      return;
    }

    const bubble = document.createElement("div");
    const size = 14 + Math.random() * 46;

    bubble.className = "moving-bubble";
    bubble.style.width = size + "px";
    bubble.style.height = size + "px";
    bubble.style.left = Math.random() * window.innerWidth + "px";
    bubble.style.animationDuration = 6 + Math.random() * 6 + "s";

    area.appendChild(bubble);

    setTimeout(function () {
      bubble.remove();
    }, 12000);
  }

  function createWhiteHeart() {
    const area = document.getElementById("whiteHeartArea");

    if (!area) {
      return;
    }

    const heart = document.createElement("div");
    const hearts = ["♡", "♥"];

    heart.className = "white-heart";
    heart.innerHTML = hearts[Math.floor(Math.random() * hearts.length)];
    heart.style.left = Math.random() * window.innerWidth + "px";
    heart.style.fontSize = 14 + Math.random() * 20 + "px";
    heart.style.animationDuration = 5 + Math.random() * 5 + "s";

    area.appendChild(heart);

    setTimeout(function () {
      heart.remove();
    }, 11000);
  }

  function createButterfly() {
    const area = document.getElementById("butterflyArea");

    if (!area) {
      return;
    }

    const butterfly = document.createElement("div");

    butterfly.className = "butterfly";
    butterfly.innerHTML = "🦋";
    butterfly.style.left = Math.random() * window.innerWidth + "px";
    butterfly.style.fontSize = 28 + Math.random() * 16 + "px";
    butterfly.style.animationDuration = 6 + Math.random() * 5 + "s";

    area.appendChild(butterfly);

    setTimeout(function () {
      butterfly.remove();
    }, 12000);
  }

  function createSideParticle() {
    const area = document.getElementById("sideParticles");

    if (!area) {
      return;
    }

    const particle = document.createElement("div");
    const type = Math.random() > 0.45 ? "star" : "soft-heart";

    particle.className = "particle " + type;

    if (type === "soft-heart") {
      particle.innerHTML = Math.random() > 0.5 ? "♡" : "♥";
    }

    const leftSide = Math.random() > 0.5;
    const startY = Math.random() * window.innerHeight;

    particle.style.top = startY + "px";
    particle.style.left = leftSide ? "-40px" : window.innerWidth + "px";

    const duration = 6 + Math.random() * 6;

    if (leftSide) {
      particle.style.animation = "birthdayFloatAcross " + duration + "s linear forwards";
    } else {
      particle.style.animation = "birthdayFloatAcrossLeft " + duration + "s linear forwards";
    }

    area.appendChild(particle);

    setTimeout(function () {
      particle.remove();
    }, (duration + 2) * 1000);
  }

  function createSparkle() {
    const area = document.getElementById("sparkleArea");

    if (!area) {
      return;
    }

    const sparkle = document.createElement("div");

    sparkle.className = "sparkle";
    sparkle.style.left = Math.random() * window.innerWidth + "px";
    sparkle.style.top = Math.random() * window.innerHeight + "px";

    area.appendChild(sparkle);

    setTimeout(function () {
      sparkle.remove();
    }, 1500);
  }

  function launchCracker() {
    const area = document.getElementById("crackerArea");

    if (!area) {
      return;
    }

    const cracker = document.createElement("div");

    cracker.className = "cracker";
    cracker.style.left = Math.random() * window.innerWidth + "px";
    cracker.style.top = Math.random() * window.innerHeight + "px";
    cracker.style.background = Math.random() > 0.5 ? "#ffffff" : "#ffd76b";

    area.appendChild(cracker);

    setTimeout(function () {
      cracker.remove();
    }, 1200);
  }

  function launchSuccessEffects() {
    for (let i = 0; i < 25; i++) {
      setTimeout(createSparkle, i * 50);
      setTimeout(launchCracker, i * 60);
    }
  }
})();